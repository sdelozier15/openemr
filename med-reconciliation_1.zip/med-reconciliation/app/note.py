"""Build a pre-filled attestation note from detected changes."""

from datetime import date
from app.models import MedChange

TYPE_LABELS = {
    "added": "ADDED",
    "stopped": "STOPPED",
    "changed": "CHANGED",
}


def build_attestation_note(patient_id: str, changes: list[MedChange]) -> str:
    today = date.today().strftime("%B %d, %Y")
    lines = [
        "MEDICATION RECONCILIATION NOTE",
        f"Date: {today}",
        f"Patient ID: {patient_id}",
        "Clinician: [Clinician name]",
        "",
        "CHANGES IDENTIFIED THIS ENCOUNTER:",
    ]

    for i, change in enumerate(changes, 1):
        label = TYPE_LABELS.get(change.type, change.type.upper())
        lines.append(f"{i}. {label} — {change.medication} · {change.detail}")

    lines += [
        "",
        "ATTESTATION:",
        "Medication list reviewed with patient. All changes discussed.",
        "Patient verbalized understanding. No unresolved discrepancies.",
        "",
        "[Clinician signature] _______________",
    ]

    return "\n".join(lines)
